import {
  useMemo,
  useState,
} from "react"

import type {
  Task,
} from "../../types/task"

import {
  TasksList,
} from "../TasksList"

import "./TaskDeviceModal.css"


interface TaskDeviceModalProps {
  device: string | null
  tasks: Task[]
  onClose: () => void
}


type TaskFilter =
  | "all"
  | "pending"
  | "progress"
  | "not-done"


function matchesFilter(
  task: Task,
  filter: TaskFilter,
): boolean {
  if (
    filter === "all"
  ) {
    return true
  }

  if (
    filter === "pending"
  ) {
    return (
      task.status_id === 199
    )
  }

  if (
    filter === "progress"
  ) {
    return (
      task.status_id === 200
    )
  }

  return (
    task.status_id === 2542
  )
}


export function TaskDeviceModal({
  device,
  tasks,
  onClose,
}: TaskDeviceModalProps) {

  const [
    activeFilter,
    setActiveFilter,
  ] = useState<TaskFilter>(
    "all"
  )


  const counts =
    useMemo(
      () => ({
        all:
          tasks.length,

        pending:
          tasks.filter(
            (task) =>
              task.status_id === 199
          ).length,

        progress:
          tasks.filter(
            (task) =>
              task.status_id === 200
          ).length,

        notDone:
          tasks.filter(
            (task) =>
              task.status_id === 2542
          ).length,
      }),
      [tasks]
    )


  const filteredTasks =
    useMemo(
      () =>
        tasks.filter(
          (task) =>
            matchesFilter(
              task,
              activeFilter
            )
        ),
      [
        tasks,
        activeFilter,
      ]
    )


  if (!device) {
    return null
  }


  return (
    <div
      className="task-device-modal__overlay"
      onMouseDown={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`Tasks for ${device}`}
    >

      <div
        className="task-device-modal"
        onMouseDown={
          (event) =>
            event.stopPropagation()
        }
      >

        <header className="task-device-modal__header">

          <div className="task-device-modal__header-top">

            <div className="task-device-modal__title-row">

              <h2>
                {device}
              </h2>

              <span className="task-device-modal__task-count">
                {tasks.length} tasks
              </span>

            </div>


            <button
              type="button"
              className="task-device-modal__close"
              onClick={onClose}
              aria-label="Close"
            >
              ×
            </button>

          </div>


          <div className="task-device-modal__filters">

            <button
              type="button"
              className={`
                task-device-modal__filter
                task-device-modal__filter--all
                ${
                  activeFilter === "all"
                    ? "task-device-modal__filter--active"
                    : ""
                }
              `}
              onClick={() =>
                setActiveFilter(
                  "all"
                )
              }
            >
              <span>
                All
              </span>

              <strong>
                {counts.all}
              </strong>
            </button>


            <button
              type="button"
              className={`
                task-device-modal__filter
                task-device-modal__filter--pending
                ${
                  activeFilter === "pending"
                    ? "task-device-modal__filter--active"
                    : ""
                }
              `}
              onClick={() =>
                setActiveFilter(
                  "pending"
                )
              }
            >
              <span>
                Pending
              </span>

              <strong>
                {counts.pending}
              </strong>
            </button>


            <button
              type="button"
              className={`
                task-device-modal__filter
                task-device-modal__filter--progress
                ${
                  activeFilter === "progress"
                    ? "task-device-modal__filter--active"
                    : ""
                }
              `}
              onClick={() =>
                setActiveFilter(
                  "progress"
                )
              }
            >
              <span>
                In process
              </span>

              <strong>
                {counts.progress}
              </strong>
            </button>


            <button
              type="button"
              className={`
                task-device-modal__filter
                task-device-modal__filter--not-done
                ${
                  activeFilter === "not-done"
                    ? "task-device-modal__filter--active"
                    : ""
                }
              `}
              onClick={() =>
                setActiveFilter(
                  "not-done"
                )
              }
            >
              <span>
                Not done
              </span>

              <strong>
                {counts.notDone}
              </strong>
            </button>

          </div>

        </header>


        <div className="task-device-modal__content">

          <TasksList
            tasks={
              filteredTasks
            }
          />

        </div>

      </div>

    </div>
  )
}